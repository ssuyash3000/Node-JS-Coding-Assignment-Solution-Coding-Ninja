import Solution from "./index.js";

Solution();
